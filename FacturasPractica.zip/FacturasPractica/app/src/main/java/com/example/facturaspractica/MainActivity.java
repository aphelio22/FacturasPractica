package com.example.facturaspractica;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.facturaspractica.IO.ApiAdapter;
import com.example.facturaspractica.IO.response.FacturasVO;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements Callback<ArrayList<FacturasVO>> {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Call<ArrayList<FacturasVO>> llamada = ApiAdapter.getApiService().getFacturas();
        llamada.enqueue(this);
    }

    @Override
    public void onResponse(Call<ArrayList<FacturasVO>> call, Response<ArrayList<FacturasVO>> response) {
        if(response.isSuccessful()) {
            ArrayList<FacturasVO> facturas= response.body();
            Log.d("onResponse facturas", "Tamaño del arreglo: " + facturas.size());

        }
    }

    @Override
    public void onFailure(Call<ArrayList<FacturasVO>> call, Throwable t) {

    }
}